# 第三问 v8 三机协作包

先读 [三机协作说明](collab/README.md)。

当前电脑建议做 C，总控和官方演练；另两台分别做 A 路线优化、B 检测优化。

各机任务说明：[机器 A](collab/START_A.md)、[机器 B](collab/START_B.md)、[机器 C](collab/START_C.md)。

本包已带开发基线缓存，候选模板尚无新算法提升。工具状态见 [交付状态](collab/TOOLKIT_STATUS.md)。
