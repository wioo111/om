# 第三问 v5 · 三机分工操作手册

## ⚠️ v5 现在完全自包含

`problem1_v4_inline.py` 已经把 Q1 v4 的核心算法（楔形交集 + Welzl 最小覆盖圆）全部内联到 v5 文件夹里。
**3 台机器只需要复制整个 `v5/` 即可，不需要单独拷 Q1 v4 源码。**

`strategy.py` 加载顺序：
1. 优先用 `v5/problem1_v4_inline.py`（自包含）
2. 找不到时再用多级 fallback 找外部 `problem1_v4.py`
3. 都找不到才会报错

## 文件清单（自包含）

```
v5/
├── problem1_v4_inline.py     ← Q1 v4 核心算法（自包含副本）
├── mock_simulator.py         ← 脱机 mock 模拟器
├── strategy.py               ← 4 套策略
├── robot.py                  ← 真模拟器 HTTP 客户端
├── selfcheck.py              ← 3 行自检
├── run_eval.py               ← 机器 A：基线
├── sweep_hybrid.py           ← 机器 B：超参扫描
├── reproduce.py              ← 机器 C：复现 + 极端 case
└── plot_results.py           ← 出 4 张对比图
```

---

## 三机部署步骤

### 在每台机器上

1. **复制整个 `v5/` 文件夹**（保留目录结构，路径任意）：
   ```
   v5/  ← 整个文件夹复制过去就行
   ```

2. （可选）如果想让 Python 能找到 v5：
   ```bash
   cd v5
   python selfcheck.py
   ```
   `selfcheck.py` 会 cd 到 v5 内部，**不需要任何环境变量、不需要任何额外路径**。

3. 跑自检（必跑）：
   ```bash
   cd v5
   python selfcheck.py
   ```
   应该看到 4 步全过 + "全部自检通过"。

---

## 机器分工

| 机器 | 任务 | 命令 | 预计耗时 | 产出 |
|---|---|---|---|---|
| A | 基线 4 策略对比 | `python run_eval.py`<br>`python plot_results.py` | 5-10 分钟 | `results/summary.{json,md}`<br>`results/figures/fig1-4.png` |
| B | Hybrid 超参扫描 | `python sweep_hybrid.py` | 10-20 分钟 | `results/sweep.{json,md}`<br>`results/figures/sweep_heatmap.png` |
| C | 复现 + 极端 case | `python reproduce.py` | 10-15 分钟 | `results/reproduce.{json,md}`<br>`results/figures/extreme_cases.png` |

**A 必跑**。B 和 C 可以同时跑。B 出最优超参，C 出稳定性证据。

---

## 同步结果

3 台都跑完后，把 `results/` 文件夹复制到任一台汇总：
- A: `summary.json`, `summary.md`, `figures/fig1-4.png`, `raw_records.json`
- B: `sweep.json`, `sweep.md`, `figures/sweep_heatmap.png`, `sweep_raw.json`
- C: `reproduce.json`, `reproduce.md`, `figures/extreme_cases.png`

---

## 真模拟器

3 台里**只选 1 台**跑真模拟器（账号互斥）：
- 推荐 A（已经跑过自检 + 基线，最熟）
- 启动模拟器 → 联网登录 → 演练测试 → `python -c "from robot import run; import json; print(json.dumps(run('Hybrid', '<你的参赛队号>'), indent=2, ensure_ascii=False))"`
- 演练结果回来后，告诉我数据，我再迭代策略

---

## 时间窗口提醒

- 模拟器截至 **2026-09-13 17:30**
- 建议 15:30 前完成所有正式测试
- 今天是 09-12，建议今晚先跑 A 的脱机 baseline，明早看结果调策略，下午演练 + 晚上正式