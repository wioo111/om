# -*- coding: utf-8 -*-
# robot.py
# 第三问：真模拟器 HTTP 客户端 + 策略调度
#
# 用法：
#   from robot import run
#   run(strategy_name='Hybrid', robot_id='<参赛队号>', base_url='http://127.0.0.1:2026')
#
# 严格按附件 1 实现：
#   - HTTP POST + JSON
#   - Content-Type: application/json
#   - 每个新动作使用新 request_id；重试复用
#   - 同时检查 HTTP 状态和 accepted
#   - 字段：arena_id, robot_id, request_id, position{x,y}, channel

import json
import uuid
from typing import Optional
from urllib import request as urlrequest
from urllib.error import URLError, HTTPError

from strategy import make_strategy, State, Action, Vec

BASE_URL = "http://127.0.0.1:2026"
ARENA_ID = "default"


class HTTPError_(Exception):
    pass


def _post(base_url: str, path: str, payload: dict,
          timeout: float = 10.0) -> dict:
    """发送 POST，解析 JSON。同时检查 HTTP 状态和 accepted。"""
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(
        base_url + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlrequest.urlopen(req, timeout=timeout) as r:
            status = r.status
            text = r.read().decode("utf-8")
    except HTTPError as e:
        status = e.code
        text = e.read().decode("utf-8", errors="ignore")
    except URLError as e:
        raise HTTPError_(f"network error: {e}") from e
    if status != 200:
        raise HTTPError_(f"HTTP {status}: {text}")
    resp = json.loads(text)
    if not resp.get("accepted", False):
        raise HTTPError_(f"accepted=false: {resp}")
    return resp


class SimulatorClient:
    """对真模拟器的薄封装。"""

    def __init__(self, base_url: str, robot_id: str):
        self.base_url = base_url
        self.robot_id = robot_id
        self._seq = 0

    def _req_id(self, prefix: str) -> str:
        self._seq += 1
        return f"{prefix}-{self._seq}-{uuid.uuid4().hex[:6]}"

    def enter(self) -> dict:
        payload = {
            "arena_id": ARENA_ID,
            "robot_id": self.robot_id,
            "request_id": self._req_id("enter"),
        }
        return _post(self.base_url, "/enter", payload)

    def measure(self, x: float, y: float, channel: int) -> dict:
        payload = {
            "arena_id": ARENA_ID,
            "robot_id": self.robot_id,
            "request_id": self._req_id("m"),
            "position": {"x": float(x), "y": float(y)},
            "channel": int(channel),
        }
        return _post(self.base_url, "/measure", payload)

    def clear(self, x: float, y: float, channel: int) -> dict:
        payload = {
            "arena_id": ARENA_ID,
            "robot_id": self.robot_id,
            "request_id": self._req_id("c"),
            "position": {"x": float(x), "y": float(y)},
            "channel": int(channel),
        }
        return _post(self.base_url, "/clear", payload)

    def exit(self) -> dict:
        payload = {
            "arena_id": ARENA_ID,
            "robot_id": self.robot_id,
            "request_id": self._req_id("exit"),
        }
        return _post(self.base_url, "/exit", payload)


# ============================================================
# 通用驱动器：策略 + 任意 Simulator-like 对象
# ============================================================
def run_with_sim(strategy_name: str, sim, max_steps: int = 5000) -> dict:
    """在任意 Simulator-like 对象上跑完一局。"""
    strategy = make_strategy(strategy_name)
    state = State(pos=(0.0, 0.0), ch=1)

    # /enter
    sim.enter()
    state.virtual_time = 0.0

    n_steps = 0
    while n_steps < max_steps:
        a = strategy.step(state)
        if a.kind == 'done':
            break
        # 在执行动作前先更新 state.pos（让策略知道下次"出发位置"）
        if a.kind in ('measure', 'clear'):
            state.pos = a.pos
            state.ch = a.ch
        if a.kind == 'measure':
            resp = sim.measure(a.pos[0], a.pos[1], a.ch)
            r = resp.measure_result
            svd = resp.svd_deg if r == 'direction' else None
            strategy.on_measure(state, a.ch, r, svd)
        elif a.kind == 'clear':
            resp = sim.clear(a.pos[0], a.pos[1], a.ch)
            success = (resp.clear_result == 'success')
            strategy.on_clear(state, a.ch, success)
        state.virtual_time = resp.virtual_time_s
        n_steps += 1
    sim.exit()
    return sim.stats()


# 薄包装：跑真模拟器
def run(strategy_name: str, robot_id: str,
        base_url: str = BASE_URL, max_steps: int = 5000) -> dict:
    cli = SimulatorClient(base_url, robot_id)
    return run_with_sim(strategy_name, cli, max_steps=max_steps)


if __name__ == "__main__":
    import sys
    name = sys.argv[1] if len(sys.argv) > 1 else 'Hybrid'
    rid = sys.argv[2] if len(sys.argv) > 2 else 'TEST'
    print(f"运行策略 {name}，robot_id={rid}")
    out = run(name, rid)
    print(json.dumps(out, indent=2, ensure_ascii=False))
